# Donation Laos

Donation Laos is a full-stack donation platform designed to facilitate charitable contributions in Laos, primarily using Lao Kip (LAK) as the currency. The platform features a user-friendly interface in the Lao language, making it accessible to local users.

## Features

- **Dashboard**: View total income, number of donations, and various statistics.
- **Profile Page**: Users can edit their personal information and connect social channels.
- **Donation Page**: A dedicated page for users to make donations easily.
- **Payment System**: Secure payment processing integrated with a payment gateway.
- **Donation Alerts**: Real-time alerts for new donations.
- **History Page**: A comprehensive list of all donations made by the user, with filters for date and amount.
- **Donation Goal Progress Bar**: Visual representation of donation goals and progress.
- **Leaderboard**: Displays top donors and their donation amounts.
- **Responsive Design**: Optimized for both mobile and desktop views.

## Project Structure

The project is organized into two main applications: the frontend and the backend.

### Frontend

- **Framework**: React
- **Routing**: React Router for navigation
- **State Management**: Context API for global state management
- **Localization**: Support for Lao language through i18n

### Backend

- **Framework**: Express.js
- **Database**: MongoDB (or any preferred database)
- **Controllers**: Separate controllers for donations, users, and payments
- **Models**: Mongoose models for donations and users
- **Payment Integration**: Services for handling payment processing

## Getting Started

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd donation-laos
   ```

3. Install dependencies for both frontend and backend:
   ```
   cd apps/frontend && npm install
   cd ../api && npm install
   ```

4. Set up environment variables:
   - Copy `.env.example` to `.env` and fill in the required values.

5. Start the development servers:
   - Frontend:
     ```
     cd apps/frontend
     npm start
     ```
   - Backend:
     ```
     cd apps/api
     npm start
     ```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.