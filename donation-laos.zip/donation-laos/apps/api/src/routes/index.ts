import { Router } from 'express';
import donationRoutes from './donations';
import userRoutes from './users';
import paymentRoutes from './payments';

const router = Router();

router.use('/donations', donationRoutes);
router.use('/users', userRoutes);
router.use('/payments', paymentRoutes);

export default router;