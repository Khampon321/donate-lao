import { Request, Response } from 'express';
import { processPayment } from '../services/paymentGateway';
import { Donation } from '../models/donation';

export const createPayment = async (req: Request, res: Response) => {
    const { amount, donorId, donationId } = req.body;

    try {
        const paymentResult = await processPayment(amount, donorId);
        
        if (paymentResult.success) {
            const donation = new Donation({
                amount,
                donorId,
                donationId,
                paymentStatus: 'completed',
                transactionId: paymentResult.transactionId,
            });

            await donation.save();
            return res.status(201).json({ message: 'Payment successful', donation });
        } else {
            return res.status(400).json({ message: 'Payment failed', error: paymentResult.error });
        }
    } catch (error) {
        return res.status(500).json({ message: 'Server error', error });
    }
};

export const getPaymentHistory = async (req: Request, res: Response) => {
    const { donorId } = req.params;

    try {
        const donations = await Donation.find({ donorId });
        return res.status(200).json(donations);
    } catch (error) {
        return res.status(500).json({ message: 'Server error', error });
    }
};