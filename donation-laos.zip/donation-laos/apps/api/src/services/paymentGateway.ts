import { Request, Response } from 'express';
import axios from 'axios';

const PAYMENT_GATEWAY_URL = 'https://api.paymentgateway.com'; // Replace with actual payment gateway URL

export const createPayment = async (req: Request, res: Response) => {
    const { amount, currency, description } = req.body;

    try {
        const response = await axios.post(`${PAYMENT_GATEWAY_URL}/create-payment`, {
            amount,
            currency,
            description,
        });

        return res.status(200).json(response.data);
    } catch (error) {
        return res.status(500).json({ message: 'Payment creation failed', error: error.message });
    }
};

export const verifyPayment = async (req: Request, res: Response) => {
    const { paymentId } = req.params;

    try {
        const response = await axios.get(`${PAYMENT_GATEWAY_URL}/verify-payment/${paymentId}`);

        return res.status(200).json(response.data);
    } catch (error) {
        return res.status(500).json({ message: 'Payment verification failed', error: error.message });
    }
};

export const generateQRCode = async (req: Request, res: Response) => {
    const { amount, currency } = req.body;

    try {
        const response = await axios.post(`${PAYMENT_GATEWAY_URL}/generate-qr`, {
            amount,
            currency,
        });

        return res.status(200).json(response.data);
    } catch (error) {
        return res.status(500).json({ message: 'QR code generation failed', error: error.message });
    }
};