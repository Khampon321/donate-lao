import { Schema, model } from 'mongoose';

const donationSchema = new Schema({
    donorId: {
        type: Schema.Types.ObjectId,
        required: true,
        ref: 'User'
    },
    amount: {
        type: Number,
        required: true
    },
    currency: {
        type: String,
        default: 'LAK'
    },
    message: {
        type: String,
        default: ''
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    goalId: {
        type: Schema.Types.ObjectId,
        ref: 'Goal'
    }
});

const Donation = model('Donation', donationSchema);

export default Donation;