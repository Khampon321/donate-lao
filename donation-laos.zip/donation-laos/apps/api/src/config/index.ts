import { config } from 'dotenv';

config();

const environment = process.env.NODE_ENV || 'development';

const configSettings = {
  development: {
    db: {
      uri: process.env.DEV_DB_URI,
    },
    server: {
      port: process.env.DEV_PORT || 5000,
    },
  },
  production: {
    db: {
      uri: process.env.PROD_DB_URI,
    },
    server: {
      port: process.env.PROD_PORT || 5000,
    },
  },
};

export const dbConfig = configSettings[environment].db;
export const serverConfig = configSettings[environment].server;