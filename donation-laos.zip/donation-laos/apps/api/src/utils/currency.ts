export const formatCurrency = (amount: number): string => {
    return `${amount.toLocaleString('en-LA')} LAK`;
};

export const parseCurrency = (amountString: string): number => {
    const parsedAmount = parseFloat(amountString.replace(/,/g, '').replace(' LAK', ''));
    return isNaN(parsedAmount) ? 0 : parsedAmount;
};