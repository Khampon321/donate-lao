import React from 'react';

interface Alert {
    id: number;
    message: string;
    type: 'success' | 'error' | 'info';
}

const Alerts: React.FC<{ alerts: Alert[]; onDismiss: (id: number) => void }> = ({ alerts, onDismiss }) => {
    return (
        <div className="alerts-container">
            {alerts.map(alert => (
                <div key={alert.id} className={`alert alert-${alert.type}`}>
                    <span>{alert.message}</span>
                    <button onClick={() => onDismiss(alert.id)}>X</button>
                </div>
            ))}
        </div>
    );
};

export default Alerts;