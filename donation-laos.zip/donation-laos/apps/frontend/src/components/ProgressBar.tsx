import React from 'react';

interface ProgressBarProps {
    currentAmount: number;
    goalAmount: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ currentAmount, goalAmount }) => {
    const progressPercentage = Math.min((currentAmount / goalAmount) * 100, 100);

    return (
        <div className="progress-bar-container">
            <div className="progress-bar" style={{ width: `${progressPercentage}%` }} />
            <div className="progress-label">
                {currentAmount} LAK of {goalAmount} LAK
            </div>
        </div>
    );
};

export default ProgressBar;