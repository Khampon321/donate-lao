import React, { useState } from 'react';

const DonationForm: React.FC = () => {
    const [amount, setAmount] = useState<number>(0);
    const [message, setMessage] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        // Here you would typically send the donation data to your API
        try {
            // Simulate API call
            await new Promise((resolve) => setTimeout(resolve, 2000));
            setMessage('ການบริจาคສໍາເລັດ!');
        } catch (error) {
            setMessage('ມີບັດສະຖານທີ່ໃນການບຣິຈາກ!');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="donation-form">
            <h2>ບຣິຈາກ</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    ຈຳນວນ (LAK):
                    <input
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(Number(e.target.value))}
                        required
                    />
                </label>
                <button type="submit" disabled={loading}>
                    {loading ? 'ກະລຸນາລໍຖໍ່...' : 'ບຣິຈາກ'}
                </button>
            </form>
            {message && <p>{message}</p>}
        </div>
    );
};

export default DonationForm;