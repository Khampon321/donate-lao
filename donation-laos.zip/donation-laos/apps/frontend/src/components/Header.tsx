import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

const Header: React.FC = () => {
    return (
        <header className="header">
            <div className="logo">
                <h1>ບັນດາບັນທຶກ</h1>
            </div>
            <nav className="navigation">
                <ul>
                    <li><Link to="/">ໜ້າຫຼັກ</Link></li>
                    <li><Link to="/donate">ບິນບັນທຶກ</Link></li>
                    <li><Link to="/dashboard">ສະຖານທີ່ບັນທຶກ</Link></li>
                    <li><Link to="/profile">ໂປຣໄຟລ໌</Link></li>
                    <li><Link to="/history">ປະຫວັດການບັນທຶກ</Link></li>
                    <li><Link to="/leaderboard">ລາງລຽງຜູ້ບັນທຶກ</Link></li>
                </ul>
            </nav>
        </header>
    );
};

export default Header;