import React from 'react';

interface DonationCardProps {
    donorName: string;
    amount: number;
    date: string;
    message?: string;
}

const DonationCard: React.FC<DonationCardProps> = ({ donorName, amount, date, message }) => {
    return (
        <div className="donation-card">
            <h3>{donorName}</h3>
            <p>ບລິການ: {amount} LAK</p>
            <p>ວັນທີ: {date}</p>
            {message && <p>ຂໍ້ຄວາມ: {message}</p>}
        </div>
    );
};

export default DonationCard;