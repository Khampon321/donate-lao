import React from 'react';
import { useMediaQuery } from 'react-responsive';

const ResponsiveLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const isMobile = useMediaQuery({ query: '(max-width: 768px)' });

    return (
        <div className={isMobile ? 'mobile-layout' : 'desktop-layout'}>
            {children}
        </div>
    );
};

export default ResponsiveLayout;