import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Function to get all donations
export const getDonations = async () => {
  const response = await apiClient.get('/donations');
  return response.data;
};

// Function to create a new donation
export const createDonation = async (donationData) => {
  const response = await apiClient.post('/donations', donationData);
  return response.data;
};

// Function to get user profile
export const getUserProfile = async (userId) => {
  const response = await apiClient.get(`/users/${userId}`);
  return response.data;
};

// Function to update user profile
export const updateUserProfile = async (userId, profileData) => {
  const response = await apiClient.put(`/users/${userId}`, profileData);
  return response.data;
};

// Function to get donation history
export const getDonationHistory = async (userId) => {
  const response = await apiClient.get(`/users/${userId}/donations`);
  return response.data;
};

// Function to get leaderboard
export const getLeaderboard = async () => {
  const response = await apiClient.get('/donations/leaderboard');
  return response.data;
};

// Function to get donation goal progress
export const getDonationGoalProgress = async () => {
  const response = await apiClient.get('/donations/goal-progress');
  return response.data;
};