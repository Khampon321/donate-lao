import React, { useEffect, useState } from 'react';
import { fetchDonationHistory } from '../services/api';
import DonationCard from '../components/DonationCard';
import './History.css';

const History = () => {
    const [donations, setDonations] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const getDonationHistory = async () => {
            try {
                const data = await fetchDonationHistory();
                setDonations(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        getDonationHistory();
    }, []);

    if (loading) {
        return <div>ກະລຸນາລໍຖໍ່ສັງຄົບ...</div>;
    }

    if (error) {
        return <div>ມີບັດສະບາຍ: {error}</div>;
    }

    return (
        <div className="history-container">
            <h1>ປະຫວັດການບິນບອນ</h1>
            {donations.length === 0 ? (
                <div>ບໍ່ມີການບິນບອນໃນປະຫວັດຂອງທ່ານ</div>
            ) : (
                donations.map((donation) => (
                    <DonationCard key={donation.id} donation={donation} />
                ))
            )}
        </div>
    );
};

export default History;