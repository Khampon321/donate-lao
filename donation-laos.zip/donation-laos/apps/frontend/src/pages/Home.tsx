import React from 'react';
import { Link } from 'react-router-dom';
import DonationCard from '../components/DonationCard';
import ProgressBar from '../components/ProgressBar';
import Alerts from '../components/Alerts';
import ResponsiveLayout from '../components/ResponsiveLayout';

const Home: React.FC = () => {
    return (
        <ResponsiveLayout>
            <header>
                <h1>ສະບາຍດີ ສູ່ ເວບໄຊທ໌ ລາວ ສໍາລັບ ການບໍ່ເບິ່ງ</h1>
                <Link to="/donate" className="donate-button">ໂອນເງິນ</Link>
            </header>
            <main>
                <ProgressBar />
                <DonationCard />
                <Alerts />
            </main>
        </ResponsiveLayout>
    );
};

export default Home;