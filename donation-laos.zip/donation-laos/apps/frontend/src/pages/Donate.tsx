import React, { useState } from 'react';
import DonationForm from '../components/DonationForm';
import ProgressBar from '../components/ProgressBar';
import Alerts from '../components/Alerts';
import { useDonationContext } from '../hooks/useDonationContext';

const Donate = () => {
    const { donations, donationGoal } = useDonationContext();
    const [alert, setAlert] = useState('');

    const handleDonationSuccess = (amount) => {
        setAlert(`ບັນທຶກການບິນບັດສຳເລັດ: ${amount} LAK`);
    };

    return (
        <div className="donate-page">
            <h1>ບິນບັດ</h1>
            <ProgressBar current={donations.reduce((acc, donation) => acc + donation.amount, 0)} goal={donationGoal} />
            <DonationForm onSuccess={handleDonationSuccess} />
            {alert && <Alerts message={alert} />}
        </div>
    );
};

export default Donate;