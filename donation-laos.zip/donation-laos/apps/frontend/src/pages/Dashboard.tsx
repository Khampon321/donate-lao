import React, { useEffect, useState } from 'react';
import { fetchDashboardData } from '../services/api';
import ProgressBar from '../components/ProgressBar';
import DonationCard from '../components/DonationCard';
import Alerts from '../components/Alerts';

const Dashboard = () => {
    const [dashboardData, setDashboardData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const getData = async () => {
            try {
                const data = await fetchDashboardData();
                setDashboardData(data);
            } catch (error) {
                console.error('Error fetching dashboard data:', error);
            } finally {
                setLoading(false);
            }
        };

        getData();
    }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div className="dashboard">
            <h1>ບັນດາຊາວລາວ</h1>
            <div className="stats">
                <h2>ລວມລາຍໄດ້: {dashboardData.totalIncome} LAK</h2>
                <h2>ຈຳນວນບິນບອນ: {dashboardData.totalDonations}</h2>
            </div>
            <ProgressBar progress={dashboardData.goalProgress} />
            <h2>ບິນບອນລ່າສຸດ</h2>
            <div className="donation-cards">
                {dashboardData.recentDonations.map(donation => (
                    <DonationCard key={donation.id} donation={donation} />
                ))}
            </div>
            <Alerts />
        </div>
    );
};

export default Dashboard;