import React, { useEffect, useState } from 'react';
import { fetchLeaderboardData } from '../services/api';
import './Leaderboard.css';

const Leaderboard = () => {
    const [leaders, setLeaders] = useState([]);

    useEffect(() => {
        const getLeaderboardData = async () => {
            const data = await fetchLeaderboardData();
            setLeaders(data);
        };

        getLeaderboardData();
    }, []);

    return (
        <div className="leaderboard-container">
            <h1>ຜູ້ບໍ່ລົງບັດ</h1>
            <table className="leaderboard-table">
                <thead>
                    <tr>
                        <th>ລະດັບ</th>
                        <th>ຊື່</th>
                        <th>ຈຳນວນບໍ່ລົງບັດ (LAK)</th>
                    </tr>
                </thead>
                <tbody>
                    {leaders.map((leader, index) => (
                        <tr key={leader.id}>
                            <td>{index + 1}</td>
                            <td>{leader.name}</td>
                            <td>{leader.amount.toLocaleString('lo-LA')} LAK</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Leaderboard;