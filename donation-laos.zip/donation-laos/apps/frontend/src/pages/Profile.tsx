import React, { useEffect, useState } from 'react';
import { getUserProfile, updateUserProfile } from '../services/api';
import { useAuth } from '../hooks/useAuth';

const Profile = () => {
    const { user } = useAuth();
    const [profileData, setProfileData] = useState({
        name: '',
        email: '',
        socialLinks: {
            facebook: '',
            twitter: '',
            instagram: ''
        }
    });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const data = await getUserProfile(user.id);
                setProfileData(data);
            } catch (err) {
                setError('Failed to load profile data');
            } finally {
                setLoading(false);
            }
        };

        fetchProfile();
    }, [user.id]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setProfileData((prevData) => ({
            ...prevData,
            [name]: value
        }));
    };

    const handleSocialChange = (e) => {
        const { name, value } = e.target;
        setProfileData((prevData) => ({
            ...prevData,
            socialLinks: {
                ...prevData.socialLinks,
                [name]: value
            }
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await updateUserProfile(user.id, profileData);
            alert('Profile updated successfully');
        } catch (err) {
            setError('Failed to update profile');
        }
    };

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div>
            <h1>ແກ້ໄຂຂໍໍລະບົບບຸກຄົນ</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>ຊື່:</label>
                    <input
                        type="text"
                        name="name"
                        value={profileData.name}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>ອີເມວ:</label>
                    <input
                        type="email"
                        name="email"
                        value={profileData.email}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <h2>ລິ້ງສັງຄົມ</h2>
                    <div>
                        <label>Facebook:</label>
                        <input
                            type="text"
                            name="facebook"
                            value={profileData.socialLinks.facebook}
                            onChange={handleSocialChange}
                        />
                    </div>
                    <div>
                        <label>Twitter:</label>
                        <input
                            type="text"
                            name="twitter"
                            value={profileData.socialLinks.twitter}
                            onChange={handleSocialChange}
                        />
                    </div>
                    <div>
                        <label>Instagram:</label>
                        <input
                            type="text"
                            name="instagram"
                            value={profileData.socialLinks.instagram}
                            onChange={handleSocialChange}
                        />
                    </div>
                </div>
                <button type="submit">ອັບເດດ</button>
            </form>
        </div>
    );
};

export default Profile;