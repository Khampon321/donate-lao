export interface Donation {
    id: string;
    amount: number;
    currency: 'LAK';
    donorId: string;
    date: Date;
    message?: string;
}

export interface User {
    id: string;
    name: string;
    email: string;
    profilePicture?: string;
    totalDonations: number;
    donationHistory: Donation[];
}

export interface DonationGoal {
    targetAmount: number;
    currentAmount: number;
    progress: number; // percentage
}

export interface LeaderboardEntry {
    userId: string;
    totalDonated: number;
}

export interface DonationAlert {
    message: string;
    donorName: string;
    amount: number;
    timestamp: Date;
}