import React from 'react';

interface ButtonProps {
    onClick: () => void;
    label: string;
    disabled?: boolean;
    variant?: 'primary' | 'secondary';
}

const Button: React.FC<ButtonProps> = ({ onClick, label, disabled = false, variant = 'primary' }) => {
    const buttonClass = variant === 'primary' ? 'btn-primary' : 'btn-secondary';

    return (
        <button className={`btn ${buttonClass}`} onClick={onClick} disabled={disabled}>
            {label}
        </button>
    );
};

export default Button;